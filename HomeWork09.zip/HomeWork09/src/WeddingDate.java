public enum WeddingDate {
    FIRST ("Ситцевая (марлевая) свадьба"),
    SECOND ("Бумажная свадьба"),
    THIRD ("Кожаная свадьба"),
    FOURTH ("Льняная свадьба"),
    FIFTH ("Деревянная свадьба"),
    SIXTH ("Чугунная свадьба"),
    SEVENTH ("Медная (Шерстяная) свадьба"),
    EIGHTH ("Жестяная свадьба"),
    NINTH ("Фаянсовая (ромашковая) свадьба"),
    TENTH ("Оловянная свадьба"),
    ELEVENTH ("Стальная свадьба"),
    TWELFTH ("Никелевая свадьба"),
    THIRTEENTH ("Кружевная (ландышевая) свадьба"),
    FOURTEENTH("Агатовая свадьба"),
    FIFTEENTH("Хрустальная (Стеклянная) свадьба");
    private final String description;

    public String getDescription() {
        return description;
    }
    WeddingDate(String description){
        this.description = description;
    }

}


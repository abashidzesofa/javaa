import javax.lang.model.util.SimpleTypeVisitor14;
import java.util.Scanner;

//Пользователь вводит, сколько лет он состоит в браке.
// Программа должна вывести,
// какая годовщина свадьбы будет у пользователя следующей
// (бумажная, ситцевая, чугунная, серебряная и.д.).
// Не обязательно указывать все годовщины, достаточно 10-15.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите сколько лет вы состоите в браке: ");
        int wedNum = scanner.nextInt();
        String message = switch (wedNum){
            case 1 -> concat(WeddingDate.FIRST);
            case 2 -> concat(WeddingDate.SECOND);
            case 3 -> concat(WeddingDate.THIRD);
            case 4 -> concat(WeddingDate.FOURTH);
            case 5 -> concat(WeddingDate.FIFTH);
            case 6 -> concat(WeddingDate.SIXTH);
            case 7 -> concat(WeddingDate.SEVENTH);
            case 8 -> concat(WeddingDate.EIGHTH);
            case 9 -> concat(WeddingDate.NINTH);
            case 10 -> concat(WeddingDate.TENTH);
            case 11 -> concat(WeddingDate.ELEVENTH);
            case 12 -> concat(WeddingDate.TWELFTH);
            case 13 -> concat(WeddingDate.THIRTEENTH);
            case 14 -> concat(WeddingDate.FOURTEENTH);
            case 15 -> concat(WeddingDate.FIFTEENTH);
            default -> "Такое количество лет в браке - большая редкость, вы счастливый человек! :)";
        };
        System.out.println(message);

    }
private static String concat (WeddingDate WD){
        return WD.name() + ":" + WD.getDescription();
}

}